# PHP BACKEND ENGINEER ASSESSMENT

## Overview

This Project is designed for different products sorting, Either by Product price or by the ratio of sales per view(sales_count divided by view_count).

## Credits
Developed by EZIEKE CHIDUBEM VICTOR.
You can reach me by my email: eziekekizito2020@gmail.com or by my phone number: 09130478678.Thanks.

## Documentation
You can check the documentation page DOCUMENTATION.md